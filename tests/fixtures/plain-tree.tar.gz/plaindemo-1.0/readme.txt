plain tarball
