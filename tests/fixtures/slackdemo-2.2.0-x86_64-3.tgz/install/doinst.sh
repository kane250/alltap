#!/bin/sh
echo "slackdemo doinst.sh executed"
